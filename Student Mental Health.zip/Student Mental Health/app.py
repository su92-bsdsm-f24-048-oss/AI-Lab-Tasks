import pickle
import json
import pandas as pd
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


try:
    with open('model_pipeline.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    with open('features.json', 'r') as features_file:
        feature_columns = json.load(features_file)
    print("Model and features loaded successfully.")
except Exception as e:
    
    print(f"Error loading model or features: {e}. Ensure prepare_model.py was executed.")
    model = None
    feature_columns = []


def create_model_input(form_data):
    """Converts user form data into the exact DataFrame format the model expects."""
    
    
    input_df = pd.DataFrame(0, index=[0], columns=feature_columns)

    
    input_df['Choose_your_gender'] = 1 if form_data.get('gender') == 'Male' else 0
    input_df['Age'] = int(form_data.get('age', 20))
    input_df['CGPA_numeric'] = float(form_data.get('cgpa', 3.0))



    course_id = form_data.get('course_id')
    course_key = f"What_is_your_course?_{course_id}"
    if course_key in input_df.columns:
        input_df[course_key] = 1
        
    
    study_year = form_data.get('study_year')
    
    
    year_key_full = f"Your_current_year_of_Study_Year {study_year}"
    year_key_lower = f"Your_current_year_of_Study_year {study_year}"

    if year_key_full in input_df.columns:
        input_df[year_key_full] = 1
    elif year_key_lower in input_df.columns:
        input_df[year_key_lower] = 1
 

    return input_df.loc[:, feature_columns]


@app.route('/', methods=['GET'])
def index():
    """Renders the main prediction form."""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """Handles the prediction request using the trained model."""
    if model is None or not feature_columns:
       
        return render_template('index.html', 
                               error_message="Server configuration error: Model files are missing or corrupt.",
                               show_result=True), 500
        
    try:
       
        form_data = request.form
        
        
        input_df = create_model_input(form_data)
        
       
        prediction = model.predict(input_df)[0]
       
        probability = model.predict_proba(input_df)[0][1] * 100 

       
        if prediction == 1:
            result_text = "High Mental Health Risk"
            advice = "Your profile shows a **higher risk** for mental health challenges. We strongly recommend seeking support or speaking to a professional."
        else:
            result_text = "Low Mental Health Risk"
            advice = "Your profile is currently categorized as **low risk**. Keep monitoring your well-being and maintain a healthy lifestyle."

        # >>> START OF NEW LOGIC ADDITION <<< 
# Add a note if the user selected the 'Completed' year, as the model was not trained on it
        if form_data.get('study_year') == 'Completed':
            advice += " **NOTE:** The model was not explicitly trained on 'Completed' student data, so this prediction is based on available demographic and course factors."
# >>> END OF NEW LOGIC ADDITION <<<

        
        return render_template('index.html', 
                               prediction_result=result_text, 
                               probability=f"{probability:.1f}%",
                               advice=advice,
                               show_result=True)

    except Exception as e:
        
        print(f"Prediction Error: {e}")
        return render_template('index.html', 
                               error_message=f"An error occurred during prediction: Please check your input values. Error details: {e}",
                               show_result=True)

if __name__ == '__main__':
   
    app.run(debug=True)