import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import pickle
import json


df = pd.read_csv('Student Mental health.csv')


df['Mental_Health_Risk'] = (df['Do_you_have_Depression?'] | df['Do_you_have_Anxiety?'] | df['Do_you_have_Panic_attack?']).astype(int)


features_to_drop = [
    'What_is_your_CGPA?',                  
    'Do_you_have_Depression?', 'Do_you_have_Anxiety?', 'Do_you_have_Panic_attack?', 'Did_you_seek_any_specialist_for_a_treatment?',
    'Mental_Health_Risk'                    
]
X = df.drop(columns=features_to_drop, errors='ignore')
y = df['Mental_Health_Risk']

for col in X.columns:
    if X[col].dtype == 'bool':
        X[col] = X[col].astype(int)


pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('model', LogisticRegression(solver='liblinear', random_state=42)) 
])


pipeline.fit(X, y)


with open('model_pipeline.pkl', 'wb') as file:
    pickle.dump(pipeline, file)


feature_names = X.columns.tolist()
with open('features.json', 'w') as file:
    json.dump(feature_names, file)

print("✅ Model trained and saved as 'model_pipeline.pkl'.")
print("✅ Feature list saved as 'features.json'.")